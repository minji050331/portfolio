jQuery(document).ready(function() {
    $('.menu').hover(function(){
        $('.submenu, .bg').stop().slideDown('fast');
    },function(){
        $('.submenu, .bg').stop().slideUp('fast');
    });

    $(".imgslide a:gt(0)").hide();
    setInterval(function() {
        $(".imgslide a:first").fadeOut()
        .next("a").fadeIn()
        .end()
        .appendTo(".imgslide")
    },2500);

    $(".notice li:first").click(function() {
        $("#pop").addClass("active");
    });
    $(".btn").click(function() {
        $("#pop").removeClass("active");
    });
});